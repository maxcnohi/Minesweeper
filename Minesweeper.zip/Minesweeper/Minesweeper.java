public class Minesweeper{
    static int[][]minefield;
    static int[][]revealed;
    static int ROW = 10;
    static int COL = 10;
    int[][]minefield = new int[10][10];
    int[][]revealed = new int[10][10]; 
    
    public Minesweeper()
    {
        
      
    }

    
    public int sampleMethod(int y)
    {
        
        return x + y;
    }
}
